# Muhammad Haris — Portfolio Website

## Publish it for free
1. Create a GitHub account at https://github.com/
2. Create a new public repository named `muhammad-haris-portfolio`.
3. Upload `index.html`.
4. Open Settings → Pages → deploy from the `main` branch.
5. GitHub will give you a public URL such as:
   https://YOURUSERNAME.github.io/muhammad-haris-portfolio/

Add that URL to your CV under your email/LinkedIn.

You can also use Netlify or another static hosting service.
